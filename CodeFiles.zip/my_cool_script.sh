#This is my better script
#Dolne usilng different approaches
#This script is not going to work
#This script is not good
